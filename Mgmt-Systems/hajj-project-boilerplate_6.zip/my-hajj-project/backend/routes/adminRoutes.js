
const express = require('express');
const router = express.Router();
const { getAllUsers, downloadExcel } = require('../controllers/adminController');
const authMiddleware = require('../middlewares/authMiddleware');

router.get('/users', authMiddleware(['admin']), getAllUsers);
router.get('/download', authMiddleware(['admin']), downloadExcel);

module.exports = router;
