import React, { useState } from 'react';
import axios from 'axios';

function UserDashboard() {
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    passportNumber: '',
    idCardNumber: '',
    paymentAmount: '',
    paymentDate: ''
  });

  const [files, setFiles] = useState({
    passportPhoto: null,
    idCardFront: null,
    idCardBack: null,
    userPicture: null,
    documents: null,
    reports: null
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    setFiles({ ...files, [e.target.name]: e.target.files[0] });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    Object.entries(form).forEach(([key, val]) => formData.append(key, val));
    Object.entries(files).forEach(([key, val]) => formData.append(key, val));

    try {
      await axios.post('/api/user/submit', formData, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'multipart/form-data'
        }
      });
      alert('Form submitted successfully!');
    } catch (err) {
      alert('Submission failed.');
    }
  };

  return (
    <div className="container mt-4">
      <h3>User Dashboard</h3>
      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <div className="row">
          <div className="col-md-6 mb-3">
            <input name="firstName" placeholder="First Name" onChange={handleChange} className="form-control" />
          </div>
          <div className="col-md-6 mb-3">
            <input name="lastName" placeholder="Last Name" onChange={handleChange} className="form-control" />
          </div>
          <div className="col-md-6 mb-3">
            <input name="passportNumber" placeholder="Passport Number" onChange={handleChange} className="form-control" />
          </div>
          <div className="col-md-6 mb-3">
            <input type="file" name="passportPhoto" onChange={handleFileChange} className="form-control" />
          </div>
          <div className="col-md-6 mb-3">
            <input name="idCardNumber" placeholder="ID Card Number" onChange={handleChange} className="form-control" />
          </div>
          <div className="col-md-6 mb-3">
            <input type="file" name="idCardFront" onChange={handleFileChange} className="form-control" />
          </div>
          <div className="col-md-6 mb-3">
            <input type="file" name="idCardBack" onChange={handleFileChange} className="form-control" />
          </div>
          <div className="col-md-6 mb-3">
            <input type="file" name="userPicture" onChange={handleFileChange} className="form-control" />
          </div>
          <div className="col-md-6 mb-3">
            <input type="file" name="documents" onChange={handleFileChange} className="form-control" />
          </div>
          <div className="col-md-6 mb-3">
            <input type="file" name="reports" onChange={handleFileChange} className="form-control" />
          </div>
          <div className="col-md-6 mb-3">
            <input name="paymentAmount" placeholder="Payment Amount" onChange={handleChange} className="form-control" />
          </div>
          <div className="col-md-6 mb-3">
            <input type="date" name="paymentDate" onChange={handleChange} className="form-control" />
          </div>
        </div>
        <button type="submit" className="btn btn-success">Submit</button>
      </form>
    </div>
  );
}

export default UserDashboard;