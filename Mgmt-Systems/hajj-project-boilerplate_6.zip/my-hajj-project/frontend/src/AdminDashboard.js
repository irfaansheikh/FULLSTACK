import React, { useEffect, useState } from 'react';
import axios from 'axios';

function AdminDashboard() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    axios.get('/api/admin/users', {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`
      }
    }).then(res => setUsers(res.data)).catch(() => alert('Failed to load users'));
  }, []);

  const downloadExcel = async () => {
    const res = await axios.get('/api/admin/export', {
      headers: {
        Authorization: `Bearer ${localStorage.getItem('token')}`
      },
      responseType: 'blob'
    });
    const url = window.URL.createObjectURL(new Blob([res.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'user-data.xlsx');
    document.body.appendChild(link);
    link.click();
  };

  return (
    <div className="container mt-4">
      <h3>Admin Dashboard</h3>
      <button className="btn btn-primary mb-3" onClick={downloadExcel}>Download Excel</button>
      <div className="table-responsive">
        <table className="table table-bordered table-striped">
          <thead>
            <tr>
              <th>Name</th>
              <th>Passport No</th>
              <th>ID No</th>
              <th>Payment</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u, i) => (
              <tr key={i}>
                <td>{u.firstName} {u.lastName}</td>
                <td>{u.passportNumber}</td>
                <td>{u.idCardNumber}</td>
                <td>{u.paymentAmount} ({u.paymentDate})</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default AdminDashboard;