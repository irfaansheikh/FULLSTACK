
const express = require('express');
const router = express.Router();
const upload = require('../middlewares/uploadMiddleware');
const { submitForm } = require('../controllers/userController');
const authMiddleware = require('../middlewares/authMiddleware');

router.post('/submit', authMiddleware(['user']), upload.any(), submitForm);

module.exports = router;
