<?php
session_start();
require 'vendor/autoload.php'; // Composer autoload
use Dompdf\Dompdf;
use PHPMailer\PHPMailer\PHPMailer;

// Database connection
$conn = new mysqli("localhost", "username", "password", "erp_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Module routing
$module = $_GET['module'] ?? 'dashboard';
$action = $_GET['action'] ?? 'index';

// Authentication check
if (!isset($_SESSION['user_id']) && $module !== 'auth') {
    header("Location: index.php?module=auth&action=login");
    exit;
}

// Module loader
$modules = [
    'dashboard' => 'DashboardController',
    'invoices' => 'InvoiceController',
    'inventory' => 'InventoryController',
    'budgeting' => 'BudgetingController',
    'products' => 'ProductController',
    'sales' => 'SalesController',
    'purchases' => 'PurchaseController',
    'accounting' => 'AccountingController',
    'hrm' => 'HRMController',
    'returns' => 'ReturnsController',
    'settings' => 'SettingsController',
    'auth' => 'AuthController'
];

if (isset($modules[$module])) {
    require "controllers/{$modules[$module]}.php";
    $controller = new $modules[$module]($conn);
    if (method_exists($controller, $action)) {
        $controller->$action();
    } else {
        die("Invalid action");
    }
} else {
    die("Invalid module");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Enterprise ERP System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="?module=dashboard">ERP System</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="?module=dashboard">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="?module=invoices">Invoices</a></li>
                    <li class="nav-item"><a class="nav-link" href="?module=inventory">Inventory</a></li>
                    <li class="nav-item"><a class="nav-link" href="?module=budgeting">Budgeting</a></li>
                    <li class="nav-item"><a class="nav-link" href="?module=products">Products</a></li>
                    <li class="nav-item"><a class="nav-link" href="?module=sales">Sales</a></li>
                    <li class="nav-item"><a class="nav-link" href="?module=purchases">Purchases</a></li>
                    <li class="nav-item"><a class="nav-link" href="?module=accounting">Accounting</a></li>
                    <li class="nav-item"><a class="nav-link" href="?module=hrm">HRM</a></li>
                    <li class="nav-item"><a class="nav-link" href="?module=returns">Returns</a></li>
                    <li class="nav-item"><a class="nav-link" href="?module=settings">Settings</a></li>
                </ul>
                <a href="?module=auth&action=logout" class="btn btn-outline-light">Logout</a>
            </div>
        </div>
    </nav>
    <div class="container my-5">
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-info"><?php echo $_SESSION['message']; unset($_SESSION['message']); ?></div>
        <?php endif; ?>
        <?php
        // Include module view
        if (file_exists("views/$module/$action.php")) {
            include "views/$module/$action.php";
        } else {
            echo "<p>View not found</p>";
        }
        ?>
    </div>
</body>
</html>