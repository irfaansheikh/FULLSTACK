<script type="text/javascript">
        var gk_isXlsx = false;
        var gk_xlsxFileLookup = {};
        var gk_fileData = {};
        function filledCell(cell) {
          return cell !== '' && cell != null;
        }
        function loadFileData(filename) {
        if (gk_isXlsx && gk_xlsxFileLookup[filename]) {
            try {
                var workbook = XLSX.read(gk_fileData[filename], { type: 'base64' });
                var firstSheetName = workbook.SheetNames[0];
                var worksheet = workbook.Sheets[firstSheetName];

                // Convert sheet to JSON to filter blank rows
                var jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1, blankrows: false, defval: '' });
                // Filter out blank rows (rows where all cells are empty, null, or undefined)
                var filteredData = jsonData.filter(row => row.some(filledCell));

                // Heuristic to find the header row by ignoring rows with fewer filled cells than the next row
                var headerRowIndex = filteredData.findIndex((row, index) =>
                  row.filter(filledCell).length >= filteredData[index + 1]?.filter(filledCell).length
                );
                // Fallback
                if (headerRowIndex === -1 || headerRowIndex > 25) {
                  headerRowIndex = 0;
                }

                // Convert filtered JSON back to CSV
                var csv = XLSX.utils.aoa_to_sheet(filteredData.slice(headerRowIndex)); // Create a new sheet from filtered array of arrays
                csv = XLSX.utils.sheet_to_csv(csv, { header: 1 });
                return csv;
            } catch (e) {
                console.error(e);
                return "";
            }
        }
        return gk_fileData[filename] || "";
        }
        </script><div class="card">
    <div class="card-header">Create Invoice</div>
    <div class="card-body">
        <form id="invoiceForm" method="POST" action="?module=invoices&action=store">
            <div class="mb-3">
                <label>Client Name</label>
                <input type="text" class="form-control" name="client_name" id="client_name" required>
                <div id="client_suggestions" class="list-group"></div>
            </div>
            <div class="mb-3">
                <label>Address</label>
                <input type="text" class="form-control" name="client_address" required>
            </div>
            <div class="mb-3">
                <label>GSTIN</label>
                <input type="text" class="form-control" name="client_gstin">
            </div>
            <div class="mb-3">
                <label>Email</label>
                <input type="email" class="form-control" name="client_email" required>
            </div>
            <div class="mb-3">
                <label>Phone</label>
                <input type="text" class="form-control" name="client_phone">
            </div>
            <div class="mb-3">
                <h3>Products</h3>
                <div id="products">
                    <div class="product row mb-2">
                        <div class="col"><input type="text" class="form-control" placeholder="Product Name" required></div>
                        <div class="col"><input type="number" class="form-control quantity" placeholder="Quantity" required></div>
                        <div class="col"><input type="number" class="form-control price" placeholder="Price" required></div>
                        <div class="col"><button type="button" class="btn btn-danger remove-product">Remove</button></div>
                    </div>
                </div>
                <button type="button" class="btn btn-secondary" id="addProduct">Add Product</button>
            </div>
            <div class="mb-3">
                <label>Discount</label>
                <input type="number" class="form-control" name="discount" value="0">
            </div>
            <input type="hidden" name="products" id="products_data">
            <button type="submit" name="create_invoice" class="btn btn-primary">Create Invoice</button>
        </form>
    </div>
</div>
<script>
    $("#addProduct").click(function() {
        $("#products").append(`
            <div class="product row mb-2">
                <div class="col"><input type="text" class="form-control" placeholder="Product Name" required></div>
                <div class="col"><input type="number" class="form-control quantity" placeholder="Quantity" required></div>
                <div class="col"><input type="number" class="form-control price" placeholder="Price" required></div>
                <div class="col"><button type="button" class="btn btn-danger remove-product">Remove</button></div>
            </div>
        `);
    });

    $(document).on("click", ".remove-product", function() {
        if ($(".product").length > 1) $(this).closest(".product").remove();
    });

    $("#invoiceForm").submit(function() {
        let products = [];
        $(".product").each(function() {
            let name = $(this).find("input").eq(0).val();
            let quantity = parseFloat($(this).find(".quantity").val());
            let price = parseFloat($(this).find(".price").val());
            products.push({ name, quantity, price });
        });
        $("#products_data").val(JSON.stringify(products));
    });

    $("#client_name").on("input", function() {
        let query = $(this).val();
        if (query.length > 2) {
            $.ajax({
                url: "suggest_client.php",
                method: "GET",
                data: { query },
                success: function(data) {
                    $("#client_suggestions").html(data);
                }
            });
        } else {
            $("#client_suggestions").empty();
        }
    });
</script>