<?php
class InvoiceController {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function index() {
        $result = $this->conn->query("SELECT * FROM invoices ORDER BY issue_date DESC");
        $invoices = $result->fetch_all(MYSQLI_ASSOC);
        include "views/invoices/index.php";
    }

    public function create() {
        include "views/invoices/create.php";
    }

    public function store() {
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_invoice'])) {
            $invoice_number = $this->generateInvoiceNumber();
            $client_name = $_POST['client_name'];
            $client_address = $_POST['client_address'];
            $client_gstin = $_POST['client_gstin'];
            $client_email = $_POST['client_email'];
            $client_phone = $_POST['client_phone'];
            $products = json_decode($_POST['products'], true);
            $subtotal = 0;
            $tax_rate = 0.18;
            $discount = $_POST['discount'] ?? 0;

            foreach ($products as $product) {
                $subtotal += $product['quantity'] * $product['price'];
            }
            $tax = $subtotal * $tax_rate;
            $grand_total = $subtotal + $tax - $discount;

            $due_date = date("Y-m-d", strtotime("+30 days"));
            $result = $this->conn->query("SELECT AVG(DATEDIFF(payment_date, issue_date)) as avg_days FROM invoices WHERE client_email='$client_email' AND payment_date IS NOT NULL");
            if ($row = $result->fetch_assoc()) {
                if ($row['avg_days']) {
                    $due_date = date("Y-m-d", strtotime("+" . round($row['avg_days']) . " days"));
                }
            }
            $payment_terms = round($row['avg_days'] ?? 30) <= 15 ? "Net 15" : "Net 30";

            $stmt = $this->conn->prepare("INSERT INTO invoices (invoice_number, client_name, client_address, client_gstin, client_email, client_phone, products, subtotal, tax, discount, grand_total, due_date, payment_terms) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $products_json = json_encode($products);
            $stmt->bind_param("sssssssdiddss", $invoice_number, $client_name, $client_address, $client_gstin, $client_email, $client_phone, $products_json, $subtotal, $tax, $discount, $grand_total, $due_date, $payment_terms);
            $stmt->execute();

            $dompdf = new Dompdf();
            $html = "<h1>Invoice #$invoice_number</h1>...</h1>"; // Simplified PDF content
            $dompdf->loadHtml($html);
            $dompdf->render();
            file_put_contents("invoices/$invoice_number.pdf", $dompdf->output());

            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.example.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'your_email@example.com';
                $mail->Password = 'your_password';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;
                $mail->setFrom('your_email@example.com', 'ERP System');
                $mail->addAddress($client_email);
                $mail->addAttachment("invoices/$invoice_number.pdf");
                $mail->isHTML(true);
                $mail->Subject = "Invoice #$invoice_number";
                $mail->Body = "Dear $client_name,<br>Please find attached your invoice.";
                $mail->send();
                $_SESSION['message'] = "Invoice created and sent!";
            } catch (Exception $e) {
                $_SESSION['message'] = "Email failed: {$mail->ErrorInfo}";
            }

            header("Location: index.php?module=invoices");
        }
    }

    private function generateInvoiceNumber() {
        $result = $this->conn->query("SELECT MAX(invoice_number) as max_num FROM invoices");
        $row = $result->fetch_assoc();
        $num = $row['max_num'] ? (int)substr($row['max_num'], 3) + 1 : 1;
        return "INV" . str_pad($num, 4, "0", STR_PAD_LEFT);
    }
}
?>