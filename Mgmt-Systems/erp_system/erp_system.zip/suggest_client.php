<?php
$conn = new mysqli("localhost", "username", "password", "erp_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = $_GET['query'];
$stmt = $conn->prepare("SELECT DISTINCT client_name, client_address, client_gstin, client_email, client_phone FROM invoices WHERE client_name LIKE ? LIMIT 5");
$like_query = "%$query%";
$stmt->bind_param("s", $like_query);
$stmt->execute();
$result = $stmt->get_result();

$output = "";
while ($row = $result->fetch_assoc()) {
    $output .= "<a href='#' class='list-group-item list-group-item-action' data-details='" . json_encode($row) . "'>" . htmlspecialchars($row['client_name']) . "</a>";
}
echo $output;
?>