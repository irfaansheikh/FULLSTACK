<?php

return [
    'option' => 'Option',
    'props' => [
        'type' => 'Type',
        'name' => 'Name',
        'color' => 'Color',
        'description' => 'Description',
    ],
];
