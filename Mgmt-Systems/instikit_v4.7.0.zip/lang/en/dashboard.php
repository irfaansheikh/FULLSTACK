<?php

return [
    'dashboard' => 'Dashboard',
    'home' => 'Home',
    'page_title' => 'Dashboard',
    'page_description' => 'Dashboard',
    'key_to_search' => ' to Search',
    'statistics' => 'Statistics',
    'fee_summary' => 'Fee Summary',
    'feed' => 'Feed',
    'no_pending_agenda' => 'There is nothing to list here.',
    'no_pending_feed' => 'There is nothing to list here.',
    'nothing_to_show' => 'There is nothing to show here.',
];
