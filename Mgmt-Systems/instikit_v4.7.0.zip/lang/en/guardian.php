<?php

return [
    'guardian' => 'Guardian',
    'guardians' => 'Guardians',
    'module_title' => 'List all Guardians',
    'module_description' => 'Manage all Guardians',
    'props' => [
        'name' => 'Guardian Name',
    ],
    'login' => [
        'login' => 'User Login',
    ],
];
