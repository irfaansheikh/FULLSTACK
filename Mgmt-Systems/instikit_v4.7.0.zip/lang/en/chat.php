<?php

return [
    'chat' => 'Chat',
    'chats' => 'Chats',
    'select_chat_tip' => 'Select a chat to start messaging!',
    'loading' => 'Loading...',
    'load_more' => 'Load More',
    'type_message' => 'Type a message...',
    'search_chats' => 'Search for chats',
    'search_users' => 'Search for users',
    'no_users_found' => 'No users found!',
    'no_chats_found' => 'No chats found!',
    'is_typing' => ':attribute is typing...',
];
