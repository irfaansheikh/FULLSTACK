<?php

return [
    'attendance' => 'Attendance',
    'assistant' => 'Attendance Assistant',
    'qr_code_attendance_disabled' => 'QR Code Attendance is disabled!',
    'qr_code' => 'Attendance QR Code',
    'marked' => 'Attendance marked successfully!',
    'qr_code_attendance_disabled' => 'QR Code Attendance is disabled!',
    'scan_qr_code' => 'Scan QR Code',
    'scan_qr_code_tip' => 'Scan the QR code to mark your attendance.',
];
