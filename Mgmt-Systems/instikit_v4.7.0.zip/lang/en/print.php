<?php

return [
    'print' => 'Print',
    'config' => 'Print Config',
    'layout' => 'Layout',
    'column' => 'Column',
    'title' => 'Title',
    'sub_title' => 'Sub Title',
    'show_header' => 'Show Header',
    'margin_top' => 'Margin Top',
    'show_print_time' => 'Show Print Time',
    'printed_at' => 'Printed At :attribute',
    'footer_note' => 'Footer Note',
    'authorized_signatory' => 'Authorized Signatory',
    'signatory1' => 'Signatory 1',
    'signatory2' => 'Signatory 2',
    'signatory3' => 'Signatory 3',
    'signatory4' => 'Signatory 4',
    'watermark' => 'Watermark',
];
