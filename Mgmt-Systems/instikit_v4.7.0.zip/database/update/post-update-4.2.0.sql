--
-- Database: `InstiKit`
--

-- --------------------------------------------------------

--
-- InstiKit 4.2.0 post update queries
--

START TRANSACTION;

SET FOREIGN_KEY_CHECKS = 0;

SET FOREIGN_KEY_CHECKS = 1;

COMMIT;