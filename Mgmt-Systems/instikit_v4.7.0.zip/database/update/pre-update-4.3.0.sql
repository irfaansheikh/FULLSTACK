--
-- Database: `InstiKit`
--

-- --------------------------------------------------------

--
-- InstiKit 4.3.0 pre update queries
--

START TRANSACTION;

SET FOREIGN_KEY_CHECKS = 0;

SET FOREIGN_KEY_CHECKS = 1;

COMMIT;