--
-- Database: `InstiKit`
--

-- --------------------------------------------------------

--
-- InstiKit 4.1.0 post update queries
--

START TRANSACTION;

SET FOREIGN_KEY_CHECKS = 0;

SET FOREIGN_KEY_CHECKS = 1;

COMMIT;