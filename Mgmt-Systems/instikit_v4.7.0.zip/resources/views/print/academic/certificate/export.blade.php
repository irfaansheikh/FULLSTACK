{!! $certificate->content !!}
