@extends('email.layout')

@section('content')
    {!! $body !!}
@endsection
