<div class="flex w-full">
    <input
        {{ $attributes->merge(['class' => 'w-full text-gray-800 dark:text-gray-400 dark:bg-transparent shadow-sm text-sm px-4 placeholder-gray-500 dark:placeholder-gray-400 focus:ring-site-primary focus:border-site-primary border-gray-700 dark:border-gray-500 rounded-md']) }} />
</div>
