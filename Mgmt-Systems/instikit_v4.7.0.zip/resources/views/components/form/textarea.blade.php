<div class="flex">
    <textarea
        {{ $attributes->merge(['class' => 'w-full block text-gray-800 dark:text-gray-400 dark:bg-transparent shadow-sm sm:text-sm px-4 placeholder-gray-500 dark:placeholder-gray-400 focus:ring-site-primary focus:border-site-primary border-gray-700 dark:border-gray-500 rounded-md']) }}></textarea>
</div>
