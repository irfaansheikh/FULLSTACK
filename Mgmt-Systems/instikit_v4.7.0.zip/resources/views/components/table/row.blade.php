@props([])

<tr>
    {{ $slot }}
</tr>
