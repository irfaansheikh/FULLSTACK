<div {{ $attributes->merge(['class' => 'container mx-auto max-w-7xl xl:px-8']) }}>
    {{ $slot }}
</div>
