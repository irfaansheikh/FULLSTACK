<x-layout>
    <p class="text-primary text-4xl font-extrabold sm:text-5xl">{{ $message }}</p>
</x-layout>
