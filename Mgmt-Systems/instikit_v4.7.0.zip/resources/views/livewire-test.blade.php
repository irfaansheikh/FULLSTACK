<x-site.layout>
    <livewire:counter />
</x-site.layout>
