<?php

return array(
    'requirements' => false,
    'database' => false,
    'admin' => false,
    'installed' => false,
);
