<?php

namespace App;

class Dashboard {
    const NAME       = 'Image Converter';
    const VERSION    = '2.0.0';
    const DEMO_MODE  = false;
}