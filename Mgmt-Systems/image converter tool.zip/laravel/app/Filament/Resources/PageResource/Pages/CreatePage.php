<?php

namespace App\Filament\Resources\PageResource\Pages;

use App\Filament\Base\BaseCreateRecord;
use App\Filament\Resources\PageResource;

class CreatePage extends BaseCreateRecord
{
    protected static string $resource = PageResource::class;
}
