<?php

namespace App\Filament\Resources\PostResource\Pages;

use App\Filament\Base\BaseCreateRecord;
use App\Filament\Resources\PostResource;

class CreatePost extends BaseCreateRecord
{
    protected static string $resource = PostResource::class;
}
