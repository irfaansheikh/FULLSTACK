<?php

namespace App\Exceptions;

class UnsupportedFormatException extends \Exception
{
}
