<x-layouts.installer>
    <div class="container max-w-3xl py-10">
        <h1 class="font-medium text-center">Installtion Process</h1>
        <section class="p-6 mt-3 text-center bg-white rounded shadow">
            <div>You are installing <strong>WebTools</strong> <span
                    class="px-2 py-1 text-xs font-bold text-white bg-teal-500 rounded-md ms-1">1.0.0</span>
            </div>
        </section>
        <livewire:installer />
    </div>
</x-layouts.installer>
