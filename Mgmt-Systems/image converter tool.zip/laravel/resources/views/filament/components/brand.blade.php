<a href="{{localizedRoute('home')}}" target="_blank">
    <h4 class="text-2xl font-bold"><span class="text-primary-500">Im</span>age <span class="text-primary-500">Co</span>nverter</h4>
</a>
