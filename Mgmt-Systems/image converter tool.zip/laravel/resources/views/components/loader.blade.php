<div class="py-20 loader" wire:loadin.block wire:target="convert">
    <div class="h-12 text-center">
        <span class="inline-block w-[.5rem] h-full bg-teal-800 animate-stretch"></span>
        <span class="inline-block w-[.5rem] h-full bg-teal-700 animate-stretch animation-delay-[-1.1s]"></span>
        <span class="inline-block w-[.5rem] h-full bg-teal-600 animate-stretch animation-delay-[-1s]"></span>
        <span class="inline-block w-[.5rem] h-full bg-teal-500 animate-stretch animation-delay-[-.9s]"></span>
        <span class="inline-block w-[.5rem] h-full bg-teal-400 animate-stretch animation-delay-[-.8s]"></span>
        <span class="inline-block w-[.5rem] h-full bg-teal-300 animate-stretch animation-delay-[-.7s]"></span>
        <span class="inline-block w-[.5rem] h-full bg-teal-200 animate-stretch animation-delay-[-.6s]"></span>
        <span class="inline-block w-[.5rem] h-full bg-teal-100 animate-stretch animation-delay-[-.5s]"></span>
    </div>
</div>
