<svg class="{{ $class ?? 'w-4 h-4' }}" fill="none" stroke="currentColor" stroke-width="{{ $strokeWidth ?? 1.5 }}"
    viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"></path>
</svg>
