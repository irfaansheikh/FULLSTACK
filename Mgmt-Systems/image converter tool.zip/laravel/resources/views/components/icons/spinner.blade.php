<svg class="{{ $class ?? 'w-4 h-4' }}" fill="none" stroke="currentColor" stroke-width="{{ $strokeWidth ?? 1.5 }}" viewBox="0 0 16 16"
    xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <circle cx="8" cy="8" r="7" stroke-opacity="0.25" vector-effect="non-scaling-stroke" />
    <path d="M15 8a7.002 7.002 0 00-7-7" stroke-linecap="round" stroke-opacity="0.5" vector-effect="non-scaling-stroke" />
</svg>
