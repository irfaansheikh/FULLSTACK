<div class="text-sm text-center converts-count lg:col-span-2">
    <span class="inline-block p-2 font-medium bg-gray-600 rounded-lg">
        {{ __('Total Converted ') }}
        <span class="font-semibold leading-4 badge">{{ $totalConverted + $initialValue }}</span>
    </span>
</div>
