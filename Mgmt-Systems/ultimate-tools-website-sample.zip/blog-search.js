/* blog-search.js placeholder */
