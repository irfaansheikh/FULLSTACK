
const User = require('../models/User');
const ExcelJS = require('exceljs');

exports.getAllUsers = async (req, res) => {
    const users = await User.find();
    res.json(users);
};

exports.downloadExcel = async (req, res) => {
    const users = await User.find();
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Users');

    worksheet.columns = [
        { header: 'Name', key: 'name' },
        { header: 'Passport Number', key: 'passportNumber' },
        { header: 'ID Card Number', key: 'idCardNumber' },
        { header: 'Payment Info', key: 'paymentInfo' },
    ];

    users.forEach(user => {
        worksheet.addRow({
            name: user.name,
            passportNumber: user.passportNumber,
            idCardNumber: user.idCardNumber,
            paymentInfo: user.paymentInfo ? `${user.paymentInfo.amount} on ${user.paymentInfo.date}` : '',
        });
    });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=users.xlsx');

    await workbook.xlsx.write(res);
    res.end();
};
