
const User = require('../models/User');

exports.submitForm = async (req, res) => {
    try {
        const userData = { ...req.body, files: req.files };
        const user = new User(userData);
        await user.save();
        res.status(201).json({ message: 'Form submitted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error submitting form' });
    }
};
