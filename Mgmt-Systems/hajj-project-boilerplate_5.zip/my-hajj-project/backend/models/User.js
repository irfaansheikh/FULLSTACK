
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    name: String,
    lastName: String,
    passportNumber: String,
    passportPhoto: String,
    idCardNumber: String,
    idCardPhoto: String,
    profilePicture: String,
    documents: [String],
    reports: [String],
    paymentInfo: {
        amount: Number,
        date: String
    },
    username: String,
    password: String,
    role: { type: String, default: 'user' }
});

module.exports = mongoose.model('User', userSchema);
