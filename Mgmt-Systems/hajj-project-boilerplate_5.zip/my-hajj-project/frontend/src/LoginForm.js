import React, { useState } from 'react';
import axios from 'axios';

function LoginForm() {
  const [form, setForm] = useState({ username: '', password: '' });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('/api/auth/login', form);
      localStorage.setItem('token', res.data.token);
      const role = res.data.role;
      window.location.href = role === 'admin' ? '/admin' : '/dashboard';
    } catch (err) {
      alert('Login failed!');
    }
  };

  return (
    <div className="container mt-5">
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <input name="username" placeholder="Username" onChange={handleChange} className="form-control mb-2" />
        <input name="password" type="password" onChange={handleChange} placeholder="Password" className="form-control mb-2" />
        <button type="submit" className="btn btn-primary">Login</button>
      </form>
    </div>
  );
}

export default LoginForm;