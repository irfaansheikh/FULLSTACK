<script> $('.chat, .chatt').click(function(){  $zopim.livechat.window.toggle(); }); </script>

<!-- Start of  Zendesk Widget script -->
<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=ab98f90e-1afd-4579-8832-7d2bce884fa9"> </script>
<!-- End of  Zendesk Widget script -->