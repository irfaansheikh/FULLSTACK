<div class="point-wrap">
			<div class="row point-wrap-responsive-slider">
				<div class="col-lg-2 col-md-4 col-sm-4">
					<div class="industrie-point">
						<ul>
							<li><i class="sprite sprite-05"></i> Engineering</li>
							<li><i class="sprite sprite-04"></i> Construcation</li>
							<li><i class="sprite sprite-03"></i> Technology</li>
							<li><i class="sprite sprite-02"></i> Automotive</li>
							<li><i class="sprite sprite-01"></i> Catalogues</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-2 col-md-4 col-sm-4">
					<div class="industrie-point">
						<ul>
							<li><i class="sprite sprite-06"></i> Religion</li>
							<li><i class="sprite sprite-07"></i> Social</li>
							<li><i class="sprite sprite-08"></i> Education</li>
							<li><i class="sprite sprite-09"></i> Resource</li>
							<li><i class="sprite sprite-10"></i> Sports</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-2 col-md-4 col-sm-4">
					<div class="industrie-point">
						<ul>
							<li><i class="sprite sprite-11"></i> Financial</li>
							<li><i class="sprite sprite-12"></i> Insurance</li>
							<li><i class="sprite sprite-12"></i> Consultation</li>
							<li><i class="sprite sprite-14"></i> Architectural</li>
							<li><i class="sprite sprite-15"></i> Food</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-2 col-md-4 col-sm-4">
					<div class="industrie-point">
						<ul>
							<li><i class="sprite sprite-16"></i> Medical</li>
							<li><i class="sprite sprite-17"></i> Health</li>
							<li><i class="sprite sprite-18"></i> Travel</li>
							<li><i class="sprite sprite-19"></i> Matrimony</li>
							<li><i class="sprite sprite-20"></i> Art</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-2 col-md-4 col-sm-4">
					<div class="industrie-point">
						<ul>
							<li><i class="sprite sprite-21"></i> Communication</li>
							<li><i class="sprite sprite-22"></i> Entertainment</li>
							<li><i class="sprite sprite-23"></i> Environmental</li>
							<li><i class="sprite sprite-24"></i> Fashion</li>
							<li><i class="sprite sprite-25"></i> Spa</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-2 col-md-4 col-sm-4">
					<div class="industrie-point">
						<ul>
							<li><i class="sprite sprite-26"></i> Children</li>
							<li><i class="sprite sprite-27"></i> Craft</li>
							<li><i class="sprite sprite-28"></i> Music</li>
							<li><i class="sprite sprite-29"></i> Navigation</li>
							<li><i class="sprite sprite-30"></i> News</li>
						</ul>
					</div>
				</div>
			</div>
		</div>