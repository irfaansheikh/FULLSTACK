<?php
$servername = "localhost"; // Change this to your MySQL server address
$username = "root"; // Change this to your MySQL username
$password = ""; // Change this to your MySQL password
$database = "ezpzbazar"; // Change this to your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);


?>
