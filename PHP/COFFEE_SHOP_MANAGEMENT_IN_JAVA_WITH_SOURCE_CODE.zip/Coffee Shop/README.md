# CoffeeShop
database

A desktop database program that allows: user signin, register a new user, add products,
delete product, make transactions, customer membership, use membership points to get 
product and so on. Data are synchronized among differnet operations.

Posgresql.