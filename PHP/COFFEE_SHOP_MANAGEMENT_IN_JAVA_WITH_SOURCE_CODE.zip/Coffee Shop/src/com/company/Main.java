package com.company;

import com.company.connection.DbAdapter;
import com.company.relations.*;
import com.company.sign.Sign;
import org.omg.Messaging.SYNC_WITH_TRANSPORT;

public class Main
{
    public static void main(String[] args) { new Sign(); }
}
