
<div class="footer">
	Developed by Satya Pramodh, Ravi Rohith.
</div>
<?php
//close connection
if(isset($connect))
mysql_close();
?>

<!--body closes-->
</div>
</body>
</html>
