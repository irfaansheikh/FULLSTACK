<div id="right_content">
<div id="content">
Welcome to our Backend
</div>
</div>