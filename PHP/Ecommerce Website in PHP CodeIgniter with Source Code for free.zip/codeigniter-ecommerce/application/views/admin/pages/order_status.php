<?php 

$this->db->update('tbl_order',$data,array('actions' => 'Done'));

?>