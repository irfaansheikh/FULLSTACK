<footer>
        <div class="footer-area">
                <p>© <?php echo date("Y");?> | Employee Leave Management System in PHP | Developed By <a href="https://codeastro.com">CodeAstro</a></p>
        </div>
</footer>