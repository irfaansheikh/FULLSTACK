</div> 
</div>
</div>
<footer class="" style="clear: both;">
	<div class="container-fluid">
		<p>&copy; 2023 | All Rights Reserverd <br> Developed By Alger Makiputin</p>
	</div>
</footer>

</body>

</html>