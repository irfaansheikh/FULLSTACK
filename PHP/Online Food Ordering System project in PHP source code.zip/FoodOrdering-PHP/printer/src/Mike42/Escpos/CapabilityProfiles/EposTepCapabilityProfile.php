<?php
namespace Mike42\Escpos\CapabilityProfiles;

class EposTepCapabilityProfile extends DefaultCapabilityProfile {
	// TODO override list of code pages
}
