module.exports = {
    mongoURI: 'YOUR_MONGODB_URL',
};