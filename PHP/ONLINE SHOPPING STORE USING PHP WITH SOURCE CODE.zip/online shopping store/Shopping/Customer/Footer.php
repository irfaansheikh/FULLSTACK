<div id="footer">  &copy; 2017 Online Clothing Store | Brought To You By <a href="https://code-projects.org/">Code-Projects</a></div>
