<?php
		include('attach/header_ind.php');
?>
	<div class="span-left" style="width:140px;visibility:hidden;">
	</div>
	<div class="span-right">
		<div class="main-container">
			 <div class="post-header">
				<span> Admin Type</span>
			 </div>
			 <div class="post-content">
				<div class="post-text">
					<ul class="home-menu">
						<a class="home-menu-link" href="school/index.php">
							<li class="home-menu-li">
								<span>
									School Admin
								</span>
							</li>
						</a>
						<a class="home-menu-link" href="college/index.php">
							<li class="home-menu-li">
								<span>
									College Admin
								</span>
							</li>
						</a>
					</ul>
				</div>
			 </div>
		</div>
	
	</div>
		<?php
		include('attach/footer_ind.php');
	
?>