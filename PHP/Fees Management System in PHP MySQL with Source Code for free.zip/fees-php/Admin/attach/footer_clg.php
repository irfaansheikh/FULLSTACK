			</div>		
		</div>
	</div>
	<script type="text/javascript" src="../js/jquery.js"></script>
	<script type="text/javascript" src="../js/script_clg.js"></script>
	
</body>
</html>