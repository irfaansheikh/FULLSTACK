			</div>		
		</div>
	</div>
	<script type="text/javascript" src="../js/jquery.js"></script>
	<script type="text/javascript" src="../js/script_sch.js"></script>
	
</body>
</html>