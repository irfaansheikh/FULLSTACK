<?php
		include('../attach/header_sch.php');
?>
	<div class="span-right">
		<div class="main-container">
			 <div class="post-header">
				<span> Home</span>
			 </div>
			 <div class="post-content">
				<div class="post-text">
					<ul class="home-menu">
						<a class="home-menu-link" href="revenue.php">
							<li class="home-menu-li">
								<span>
									Revenue
								</span>
							</li>
						</a>
						<a class="home-menu-link" href="today.php">
							<li class="home-menu-li">
								<span>
									Today's Transaction
								</span>
							</li>
						</a>
					</ul>
				</div>
			 </div>
		</div>
	
	</div>
		<?php
		include('../attach/footer_sch.php');
	
?>