 <?php
 1. what is "caste, religion and subcaste" doing in (Admin>>Add Class)
 /*so i removed it for time well being*/
 2.what is the type of fee in admin>set fee and admin>>create class ??
 /*I assumed some names and working with them*/
 
 /*admin>>set fee >> add fee is not working in mozilla*/
 ?>