
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="css/index.css"/>
		<title>FMS</title>
		<head>
			<style type="text/css">
				/* body{
					background-image:url('img/bg.jpg');
					background-repeat:no-repeat;
					background-size:1400px 760px;
				} */
				div.main-container{
					background-color:#fff;
					opacity:0.85;
				}
			</style>
		</head>
	</head>
	<body>
	<div class="wrapper">
		<div class="nav-bar">
			<div class="nav-bar-inner">
				<div class="menu-container">
					<h3>Fees Management System</h3>
				</div>
				<div class="sub-container">
					<ul class="sub-container-menu">
						<li class="header-menu">
						Hello, User
						</li>
					</ul>
				</div>
			</div>
		</div>			
		<div class="cover">	
			<div class="row">	
				