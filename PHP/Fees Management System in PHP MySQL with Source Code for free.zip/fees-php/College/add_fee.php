<?php
	include('../attach/header_clg.php');
?>
<div class="span-right print_rec">	
	<div class="main-container no-print">
		<div class="post-header">
			<span> Add Fee</span>
		</div>
		<div class="post-content">
			<div class="post-text">
				<form class="sch_fee_grn" action="" method="POST">
					 <div class="box-left">
						GR/SR no. <input  type="text" name="sch_grn">
					</div>
					<div class="box-right">
						<button class="sch_fee_grn_sub"><span>look-up</span></button>
					</div>
				</form>
			</div>
		</div>
	 </div>
	 <div class="sch_fee_div">
	 </div>
	 


	<?php
	include('../attach/footer_clg.php');
?>
