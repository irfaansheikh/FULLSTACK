var OneSignal = window.OneSignal || [];
  OneSignal.push(function() {
    OneSignal.init({
      appId: "c7203da0-332c-4ab4-bf61-9e3802b93cb8",
    });
  });