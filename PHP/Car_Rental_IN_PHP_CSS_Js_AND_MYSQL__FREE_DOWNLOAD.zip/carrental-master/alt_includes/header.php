
<div class="brand shadowed shadow" style="padding:7px;background-color:#39383d !important; color:#fff; margin-bottom:5%;"> 
	<a href="index.php" style="font-size: 20px; text-align:center; color:#fff; margin:0.4% auto !important; margin-left:4%;" class=" btn btn-primary text-center m-auto" ><i class="fa fa-car"></i>&nbsp; EZRent</a>  
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav" style="margin:0 !important; background-color:black;">
			<li class="ts-account">
				<a href="#"><?php echo $_SESSION['fname'] ?> Options<i class="fa fa-angle-down hidden-side"></i></a>
				<ul>
				    
					<li><a href="index.php">Home</a></li>
					<li><a href="manage-bookings.php" id="manage-bookings">Manage Bookings</a></li>
					<li><a href="my-vehicles.php" id="my-vehicles">My Vehicles</a></li>
					<li><a href="add-vehicle.php" id="add-vehicles">Add Vehicle</a></li>
					<li><a href="locations.php">View Renters Locations</a></li>
				</ul>
			</li>
		</ul>
	</div>


<div style="margin-bottom:8%;"></div>
