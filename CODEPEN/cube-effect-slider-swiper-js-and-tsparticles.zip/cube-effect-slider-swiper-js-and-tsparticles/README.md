# Cube Effect Slider | Swiper JS and tsParticles

A Pen created on CodePen.io. Original URL: [https://codepen.io/IrfanSheikh/pen/OJYGGvQ](https://codepen.io/IrfanSheikh/pen/OJYGGvQ).

This pen is a responsive landing page. It has a slider with the cube effect by Swiper JS and tsParticles is used for the animated background.

Note: This project can be accessible but it is not meant for unlimited use. Please, do not use it in profit-making platforms and projects without permission.