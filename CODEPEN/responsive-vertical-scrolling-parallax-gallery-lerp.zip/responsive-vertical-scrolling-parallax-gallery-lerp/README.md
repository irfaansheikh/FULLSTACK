# Responsive Vertical Scrolling Parallax Gallery ( Lerp )

A Pen created on CodePen.io. Original URL: [https://codepen.io/IrfanSheikh/pen/ZENZZxN](https://codepen.io/IrfanSheikh/pen/ZENZZxN).

