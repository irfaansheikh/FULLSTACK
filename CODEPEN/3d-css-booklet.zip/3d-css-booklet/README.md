# 3d css Booklet

A Pen created on CodePen.io. Original URL: [https://codepen.io/IrfanSheikh/pen/jOoRRzQ](https://codepen.io/IrfanSheikh/pen/jOoRRzQ).

Had a go at doing a page turning effect and I thought the best way to do it would be with 3d css.
The tricky bit is making sure the pages dont clip though eachother when they turn and land which was troublesome using z-index.