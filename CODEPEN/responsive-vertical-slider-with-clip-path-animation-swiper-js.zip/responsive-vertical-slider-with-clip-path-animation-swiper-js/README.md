# Responsive Vertical Slider with Clip-Path Animation | Swiper JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/IrfanSheikh/pen/PovggQO](https://codepen.io/IrfanSheikh/pen/PovggQO).

This pen features a responsive vertical slider created with Swiper JS. It includes an animation using clip-path, and you can navigate the slides both by clicking on the pagination and using the mouse wheel.