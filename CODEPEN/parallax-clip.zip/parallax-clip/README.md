# Parallax clip

A Pen created on CodePen.io. Original URL: [https://codepen.io/IrfanSheikh/pen/zYQXXgr](https://codepen.io/IrfanSheikh/pen/zYQXXgr).

Parallax scrolling where logo disappears into the background image

Background image from unsplash.com by David Marcu