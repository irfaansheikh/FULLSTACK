# Parallax Bubbles

A Pen created on CodePen.io. Original URL: [https://codepen.io/IrfanSheikh/pen/zYQXQOr](https://codepen.io/IrfanSheikh/pen/zYQXQOr).

Something I am trying out for use in a class project. I still need to do cross-browser testing, etc.

JQuery is from Jonathan Nicol's parallax tutorial: http://bit.ly/1et2LTm