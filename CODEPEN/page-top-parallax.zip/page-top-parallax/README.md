# Page top parallax

A Pen created on CodePen.io. Original URL: [https://codepen.io/IrfanSheikh/pen/gOJyyNz](https://codepen.io/IrfanSheikh/pen/gOJyyNz).

Page top parallax (SVG + CSS Variables)

How to create the SVG masks:

* Import an image into Illustrator (or some other vector program)
* Select the image and size the artboard to fit the image 
* Create a layer for each parallax part and draw a white shape to be used as mask

<img src="https://user-images.githubusercontent.com/1699461/40590009-1ca9410a-61f8-11e8-8781-0a1040438bd8.png" />

* Each layer name will turn up as id's in the final SVG code
* When done click save as and select SVG 
* In the next dialog window click the "SVG Code..." button (I'm using an old CS6)
* Select and copy the code 
* Go to https://jakearchibald.github.io/svgomg to clean up the code
* Paste the output in the HTML window on codepen
* Wrap the id groups/paths in mask tags and move the ids here
* That's about it :-)


UPDATE

Changed markup to use div wrappers for better animation performance.  SVG's will cause repaint even if you only animate transforms.