# Pure CSS One Div House Responsive Animation | CSS Art

A Pen created on CodePen.io. Original URL: [https://codepen.io/IrfanSheikh/pen/eYaoobO](https://codepen.io/IrfanSheikh/pen/eYaoobO).

