#  Scroll Game: Dark Run

A Pen created on CodePen.io. Original URL: [https://codepen.io/IrfanSheikh/pen/KKLYYQr](https://codepen.io/IrfanSheikh/pen/KKLYYQr).

A Horizontal Scrolling Journey Through the Darkness to Find Home. Your goal: survive and reach home in the best time possible.
Image Credits : Freepik.
