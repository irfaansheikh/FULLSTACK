# Parallax Depth Cards

A Pen created on CodePen.io. Original URL: [https://codepen.io/IrfanSheikh/pen/gOJyyjo](https://codepen.io/IrfanSheikh/pen/gOJyyjo).

After playing the Gwent Closed Beta from CD Projekt Red, I had to try this concept of parallaxed backgrounds and layers in cards. I'm thinking this could be really nice for my next portfolio site.