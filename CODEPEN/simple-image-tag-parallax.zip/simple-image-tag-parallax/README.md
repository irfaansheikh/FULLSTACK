# Simple Image Tag Parallax

A Pen created on CodePen.io. Original URL: [https://codepen.io/IrfanSheikh/pen/gOJyyKX](https://codepen.io/IrfanSheikh/pen/gOJyyKX).

An image tag parallax effect with speed control, image always centered and without LAG, it's also responsive! I know that the code could be better, if you have some tips or improvement, please let me know.