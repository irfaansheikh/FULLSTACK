# +480 challenges in 365 days on iCodeThis

A Pen created on CodePen.io. Original URL: [https://codepen.io/IrfanSheikh/pen/eYaooVw](https://codepen.io/IrfanSheikh/pen/eYaooVw).

I completed at least 1 challenge per day for the last 365 days on iCodeThis.com