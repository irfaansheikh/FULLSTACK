# Canvas Parallax Skyline

A Pen created on CodePen.io. Original URL: [https://codepen.io/IrfanSheikh/pen/vYwMMaZ](https://codepen.io/IrfanSheikh/pen/vYwMMaZ).

This pen was inspired by [Random Skyline](http://codepen.io/moklick/pen/riJFp) by [moklick](http://codepen.io/moklick). Move your mouse to change speed and move up and down. It would be cool to implement this as a background for a game. I am utilizing [Sketch.js](https://github.com/soulwire/sketch.js) in this pen.