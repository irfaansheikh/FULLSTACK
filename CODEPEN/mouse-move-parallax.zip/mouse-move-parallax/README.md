# Mouse Move Parallax ✨

A Pen created on CodePen.io. Original URL: [https://codepen.io/IrfanSheikh/pen/bGyJJQx](https://codepen.io/IrfanSheikh/pen/bGyJJQx).

Simple vanilla javascript parallax.