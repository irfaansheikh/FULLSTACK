# Parallax Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/IrfanSheikh/pen/MWdRdWW](https://codepen.io/IrfanSheikh/pen/MWdRdWW).

After vectors are split and turned into layers, GreenSock ScrollTrigger is used for the parallax effect.

Note: Please, do not use it in profit-making platforms and projects without permission.