# Tic-Tac-Toe

Tic-Tac-Toe game created with HTML, CSS and JS.

[Live Demo](https://michalosman.github.io/tic-tac-toe/) :point_left:
