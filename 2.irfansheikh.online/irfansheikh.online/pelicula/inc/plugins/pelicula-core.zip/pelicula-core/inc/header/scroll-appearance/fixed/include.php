<?php

include_once PELICULA_CORE_INC_PATH . '/header/scroll-appearance/fixed/helper.php';