<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<?php
		// Include post format part
		pelicula_core_theme_template_part( 'blog', 'templates/parts/post-format/quote', '', array( 'title_tag' => 'h6', 'author_title_tag' => 'span' ) ); ?>
	</div>
</article>