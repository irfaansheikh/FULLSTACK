<?php

include_once PELICULA_CORE_INC_PATH . '/icons/material-icons/material-icons.php';