<?php

include_once PELICULA_CORE_INC_PATH . '/core-dashboard/rest/rest.php';