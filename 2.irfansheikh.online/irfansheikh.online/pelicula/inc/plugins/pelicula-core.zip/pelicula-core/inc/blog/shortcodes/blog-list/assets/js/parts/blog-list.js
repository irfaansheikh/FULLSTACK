(function ($) {
	
	"use strict";
	qodefCore.shortcodes.pelicula_core_blog_list = {};
	qodefCore.shortcodes.pelicula_core_blog_list.qodefPagination = qodef.qodefPagination;
	qodefCore.shortcodes.pelicula_core_blog_list.qodefFilter = qodef.qodefFilter;
	qodefCore.shortcodes.pelicula_core_blog_list.qodefJustifiedGallery = qodef.qodefJustifiedGallery;
	qodefCore.shortcodes.pelicula_core_blog_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.pelicula_core_blog_list.qodefSwiper = qodef.qodefSwiper;
	qodefCore.shortcodes.pelicula_core_blog_list.qodefMainContent = qodef.qodefMainContent;

})(jQuery);