<?php

include_once PELICULA_CORE_INC_PATH . '/header/layouts/vertical/helper.php';
include_once PELICULA_CORE_INC_PATH . '/header/layouts/vertical/vertical-header.php';
include_once PELICULA_CORE_INC_PATH . '/header/layouts/vertical/dashboard/admin/vertical-header-options.php';
include_once PELICULA_CORE_INC_PATH . '/header/layouts/vertical/dashboard/meta/vertical-header-meta.php';