<?php

include_once PELICULA_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/blog-list.php';