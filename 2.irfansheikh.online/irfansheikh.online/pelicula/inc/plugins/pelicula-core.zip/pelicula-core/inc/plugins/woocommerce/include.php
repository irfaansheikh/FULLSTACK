<?php

include_once PELICULA_CORE_PLUGINS_PATH . '/woocommerce/woocommerce.php';