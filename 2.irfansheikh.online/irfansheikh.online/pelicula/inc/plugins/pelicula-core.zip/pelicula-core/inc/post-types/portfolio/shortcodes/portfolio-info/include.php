<?php
include_once PELICULA_CORE_CPT_PATH . '/portfolio/shortcodes/portfolio-info/portfolio-info.php';