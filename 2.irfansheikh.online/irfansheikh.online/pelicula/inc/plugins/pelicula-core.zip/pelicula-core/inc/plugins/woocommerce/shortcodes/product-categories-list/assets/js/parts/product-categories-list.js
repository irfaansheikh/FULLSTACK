(function ($) {
    "use strict";

	qodefCore.shortcodes.pelicula_core_product_categories_list = {};
	qodefCore.shortcodes.pelicula_core_product_categories_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.pelicula_core_product_categories_list.qodefSwiper = qodef.qodefSwiper;
	qodefCore.shortcodes.pelicula_core_product_categories_list.qodefMainContent = qodef.qodefMainContent;

})(jQuery);