<?php

include_once PELICULA_CORE_INC_PATH . '/media/list-image-sizes/list-image-sizes.php';