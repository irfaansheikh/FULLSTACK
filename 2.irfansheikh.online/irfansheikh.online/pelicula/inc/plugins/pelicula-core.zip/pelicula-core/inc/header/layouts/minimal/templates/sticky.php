<div class="qodef-header-sticky">
	<div class="qodef-header-sticky-inner <?php echo apply_filters( 'pelicula_filter_header_inner_class', '' ); ?>">
		<?php pelicula_core_get_header_logo_image( array( 'sticky_logo' => true ) ); ?>
		<?php pelicula_core_get_opener_icon_html( array(
			'option_name'  => 'fullscreen_menu',
			'custom_class' => 'qodef-fullscreen-menu-opener'
		), true ); ?>
	</div>
</div>