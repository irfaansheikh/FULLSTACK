<?php

include_once PELICULA_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/minimal/minimal.php';