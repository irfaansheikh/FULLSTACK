<?php

include_once PELICULA_CORE_CPT_PATH . '/post-types.php';