<?php

include_once PELICULA_CORE_INC_PATH . '/media/helper.php';