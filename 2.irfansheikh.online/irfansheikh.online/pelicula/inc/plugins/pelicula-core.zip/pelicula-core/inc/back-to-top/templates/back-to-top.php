<a id="qodef-back-to-top" href="#">
    <span class="qodef-back-to-top-icon">
		<?php echo qode_framework_icons()->get_specific_icon_from_pack( 'back-to-top', 'elegant-icons' ); ?>
    </span>
    <span class="qodef-btn-bg-holder "></span>
</a>