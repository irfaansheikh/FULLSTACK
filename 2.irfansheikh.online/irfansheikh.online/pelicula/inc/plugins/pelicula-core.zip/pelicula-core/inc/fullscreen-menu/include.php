<?php

include_once PELICULA_CORE_INC_PATH . '/fullscreen-menu/helper.php';
include_once PELICULA_CORE_INC_PATH . '/fullscreen-menu/dashboard/admin/fullscreen-menu-options.php';
include_once PELICULA_CORE_INC_PATH . '/fullscreen-menu/dashboard/admin/fullscreen-menu-typography-options.php';