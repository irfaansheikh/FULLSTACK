<?php

include_once PELICULA_CORE_INC_PATH . '/icons/linea-icons/linea-icons.php';