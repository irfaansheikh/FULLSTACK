<?php

include_once PELICULA_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/dropdown-cart.php';