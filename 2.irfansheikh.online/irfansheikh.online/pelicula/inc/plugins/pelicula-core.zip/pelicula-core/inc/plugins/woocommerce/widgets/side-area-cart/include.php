<?php

include_once PELICULA_CORE_PLUGINS_PATH . '/woocommerce/widgets/side-area-cart/side-area-cart.php';