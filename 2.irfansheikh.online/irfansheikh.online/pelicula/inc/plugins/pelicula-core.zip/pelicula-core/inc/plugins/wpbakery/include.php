<?php

include_once PELICULA_CORE_PLUGINS_PATH . '/wpbakery/helper.php';