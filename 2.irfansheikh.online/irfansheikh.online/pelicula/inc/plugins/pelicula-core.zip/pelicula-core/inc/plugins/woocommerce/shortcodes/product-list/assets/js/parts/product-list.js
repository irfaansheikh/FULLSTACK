(function ($) {
	
    "use strict";
	qodefCore.shortcodes.pelicula_core_product_list = {};
	qodefCore.shortcodes.pelicula_core_product_list.qodefPagination = qodef.qodefPagination;
	qodefCore.shortcodes.pelicula_core_product_list.qodefFilter = qodef.qodefFilter;
	qodefCore.shortcodes.pelicula_core_product_list.qodefJustifiedGallery = qodef.qodefJustifiedGallery;
	qodefCore.shortcodes.pelicula_core_product_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.pelicula_core_product_list.qodefSwiper = qodef.qodefSwiper;
	qodefCore.shortcodes.pelicula_core_product_list.qodefMainContent = qodef.qodefMainContent;

})(jQuery);