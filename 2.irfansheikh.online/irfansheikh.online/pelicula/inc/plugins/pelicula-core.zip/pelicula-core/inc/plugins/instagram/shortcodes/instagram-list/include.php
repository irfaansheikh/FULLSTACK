<?php

include_once PELICULA_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/instagram-list.php';