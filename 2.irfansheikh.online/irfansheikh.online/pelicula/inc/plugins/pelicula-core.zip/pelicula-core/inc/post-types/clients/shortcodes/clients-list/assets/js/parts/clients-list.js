(function ($) {
    "use strict";

    qodefCore.shortcodes.pelicula_core_clients_list = {};
    qodefCore.shortcodes.pelicula_core_clients_list.qodefSwiper = qodef.qodefSwiper;
})(jQuery);