<?php
echo wp_kses_post( $logo_dark_image );
echo wp_kses_post( $logo_light_image );