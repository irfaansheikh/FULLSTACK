<div class="qodef-m-action">
	<a itemprop="url" href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="qodef-m-action-link"><?php esc_html_e( 'View Cart', 'pelicula-core' ); ?></a>
	<span class="qodef-m-action-separator"></span>
	<a itemprop="url" href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="qodef-m-action-link"><?php esc_html_e( 'Checkout', 'pelicula-core' ); ?></a>
</div>