<?php

define( 'PELICULA_CORE_VERSION', '1.0' );
define( 'PELICULA_CORE_ABS_PATH', dirname( __FILE__ ) );
define( 'PELICULA_CORE_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'PELICULA_CORE_URL_PATH', plugin_dir_url( __FILE__ ) );
define( 'PELICULA_CORE_ASSETS_PATH', PELICULA_CORE_ABS_PATH . '/assets' );
define( 'PELICULA_CORE_ASSETS_URL_PATH', PELICULA_CORE_URL_PATH . 'assets' );
define( 'PELICULA_CORE_INC_PATH', PELICULA_CORE_ABS_PATH . '/inc' );
define( 'PELICULA_CORE_INC_URL_PATH', PELICULA_CORE_URL_PATH . 'inc' );
define( 'PELICULA_CORE_CPT_PATH', PELICULA_CORE_INC_PATH . '/post-types' );
define( 'PELICULA_CORE_CPT_URL_PATH', PELICULA_CORE_INC_URL_PATH . '/post-types' );
define( 'PELICULA_CORE_SHORTCODES_PATH', PELICULA_CORE_INC_PATH . '/shortcodes' );
define( 'PELICULA_CORE_SHORTCODES_URL_PATH', PELICULA_CORE_INC_URL_PATH . '/shortcodes' );
define( 'PELICULA_CORE_PLUGINS_PATH', PELICULA_CORE_INC_PATH . '/plugins' );
define( 'PELICULA_CORE_PLUGINS_URL_PATH', PELICULA_CORE_INC_URL_PATH . '/plugins' );
define( 'PELICULA_CORE_HEADER_LAYOUTS_PATH', PELICULA_CORE_INC_PATH . '/header/layouts' );
define( 'PELICULA_CORE_HEADER_LAYOUTS_URL_PATH', PELICULA_CORE_INC_URL_PATH . '/header/layouts' );
define( 'PELICULA_CORE_HEADER_ASSETS_PATH', PELICULA_CORE_INC_PATH . '/header/assets' );
define( 'PELICULA_CORE_HEADER_ASSETS_URL_PATH', PELICULA_CORE_INC_URL_PATH . '/header/assets' );

define( 'PELICULA_CORE_MENU_NAME', 'pelicula_core_menu' );
define( 'PELICULA_CORE_OPTIONS_NAME', 'pelicula_core_options' );

define( 'PELICULA_CORE_PROFILE_SLUG', 'edge' );