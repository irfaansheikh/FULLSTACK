<?php

require_once QODE_FRAMEWORK_INC_PATH . '/widgets/qode-widgets.php';
require_once QODE_FRAMEWORK_INC_PATH . '/widgets/qode-widget.php';

require_once QODE_FRAMEWORK_INC_PATH . '/widgets/fields/field-type.php';
require_once QODE_FRAMEWORK_INC_PATH . '/widgets/fields/field-color.php';
require_once QODE_FRAMEWORK_INC_PATH . '/widgets/fields/field-select.php';
require_once QODE_FRAMEWORK_INC_PATH . '/widgets/fields/field-text.php';
require_once QODE_FRAMEWORK_INC_PATH . '/widgets/fields/field-textarea.php';
require_once QODE_FRAMEWORK_INC_PATH . '/widgets/fields/field-iconpack.php';
require_once QODE_FRAMEWORK_INC_PATH . '/widgets/fields/field-icon.php';
require_once QODE_FRAMEWORK_INC_PATH . '/widgets/fields/field-image.php';