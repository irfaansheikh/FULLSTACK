<?php

require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/front-end/core/options.php';
require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/front-end/core/page.php';
require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/front-end/core/row.php';
require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/front-end/core/section.php';
require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/front-end/core/tab.php';