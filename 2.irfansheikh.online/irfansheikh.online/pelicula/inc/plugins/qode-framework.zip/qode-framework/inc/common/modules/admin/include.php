<?php

require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/admin/core/options.php';
require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/admin/core/page.php';
require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/admin/core/row.php';
require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/admin/core/section.php';
require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/admin/core/tab.php';