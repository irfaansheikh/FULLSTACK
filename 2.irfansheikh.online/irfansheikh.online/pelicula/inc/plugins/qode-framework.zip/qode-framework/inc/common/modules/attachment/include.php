<?php

require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/attachment/core/options.php';
require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/attachment/core/page.php';