<?php

require_once QODE_FRAMEWORK_INC_PATH . '/post-types/custom-post-type-taxonomy.php';
require_once QODE_FRAMEWORK_INC_PATH . '/post-types/custom-post-type.php';
require_once QODE_FRAMEWORK_INC_PATH . '/post-types/custom-post-types.php';