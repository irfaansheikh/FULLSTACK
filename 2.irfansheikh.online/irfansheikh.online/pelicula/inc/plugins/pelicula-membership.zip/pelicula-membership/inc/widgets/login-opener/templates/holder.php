<?php

if ( is_user_logged_in() ) {
	pelicula_membership_template_part( 'widgets/login-opener', 'templates/logged-in-content' );
} else {
	pelicula_membership_template_part( 'widgets/login-opener', 'templates/logged-out-content' );
}