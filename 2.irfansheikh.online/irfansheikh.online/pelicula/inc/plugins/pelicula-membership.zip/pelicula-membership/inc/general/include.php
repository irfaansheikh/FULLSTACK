<?php

require_once PELICULA_MEMBERSHIP_INC_PATH . '/general/register-template.php';
include_once PELICULA_MEMBERSHIP_INC_PATH . '/general/helper.php';