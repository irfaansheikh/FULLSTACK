<?php

include_once PELICULA_MEMBERSHIP_LOGIN_MODAL_PATH . '/helper.php';

foreach ( glob( PELICULA_MEMBERSHIP_LOGIN_MODAL_PATH . '/*/include.php' ) as $module ) {
	include_once $module;
}