<?php

include_once PELICULA_INC_ROOT_DIR . '/404/helper.php';