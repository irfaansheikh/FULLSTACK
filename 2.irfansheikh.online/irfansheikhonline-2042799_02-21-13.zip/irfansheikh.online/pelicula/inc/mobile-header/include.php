<?php

include_once PELICULA_INC_ROOT_DIR . '/mobile-header/helper.php';