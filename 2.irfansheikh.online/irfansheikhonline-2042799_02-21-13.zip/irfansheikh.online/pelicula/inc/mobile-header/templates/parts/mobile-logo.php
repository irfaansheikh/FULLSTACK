<a itemprop="url" class="qodef-mobile-header-logo-link" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
	<?php
	// Include mobile header logo image html
	echo pelicula_get_header_logo_image(true); ?>
</a>