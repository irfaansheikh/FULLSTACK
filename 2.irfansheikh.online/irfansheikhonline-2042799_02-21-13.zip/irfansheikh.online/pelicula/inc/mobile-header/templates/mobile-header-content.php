<?php

// Include mobile logo
pelicula_template_part( 'mobile-header', 'templates/parts/mobile-logo' );

// Include mobile navigation opener
pelicula_template_part( 'mobile-header', 'templates/parts/mobile-navigation-opener' );

// Include mobile navigation
pelicula_template_part( 'mobile-header', 'templates/parts/mobile-navigation' );