<?php

include_once PELICULA_INC_ROOT_DIR . '/welcome/welcome.php';