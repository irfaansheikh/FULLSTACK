<?php

include_once PELICULA_INC_ROOT_DIR . '/content/helper.php';