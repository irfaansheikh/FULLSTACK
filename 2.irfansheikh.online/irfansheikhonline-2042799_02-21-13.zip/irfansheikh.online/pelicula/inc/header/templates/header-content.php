<?php

// Include logo
pelicula_template_part( 'header', 'templates/parts/logo' );

// Include main navigation
pelicula_template_part( 'header', 'templates/parts/navigation' );