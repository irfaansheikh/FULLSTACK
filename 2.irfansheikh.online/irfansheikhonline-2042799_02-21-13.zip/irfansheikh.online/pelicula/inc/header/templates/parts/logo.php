<a itemprop="url" class="qodef-header-logo-link qodef-height--not-set" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
	<?php
	// Include header logo image html
	echo pelicula_get_header_logo_image(); ?>
</a>