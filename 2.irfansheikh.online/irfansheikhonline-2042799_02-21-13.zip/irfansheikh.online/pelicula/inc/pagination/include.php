<?php

include_once PELICULA_INC_ROOT_DIR . '/pagination/helper.php';