<?php

// Include page footer top area
pelicula_template_part( 'footer', 'templates/parts/footer-top-area' );

// Include page footer bottom area
pelicula_template_part( 'footer', 'templates/parts/footer-bottom-area' );