<?php

include_once PELICULA_INC_ROOT_DIR . '/footer/helper.php';