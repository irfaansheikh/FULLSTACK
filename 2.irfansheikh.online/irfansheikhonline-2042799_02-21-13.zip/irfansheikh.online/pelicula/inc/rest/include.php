<?php

include_once PELICULA_INC_ROOT_DIR . '/rest/rest.php';