<?php

include_once PELICULA_INC_ROOT_DIR . '/plugins/class-tgm-plugin-activation.php';
include_once PELICULA_INC_ROOT_DIR . '/plugins/plugins-activation.php';