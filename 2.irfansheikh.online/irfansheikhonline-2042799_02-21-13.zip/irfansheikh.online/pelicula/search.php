<?php

get_header();

// Include content template
pelicula_template_part( 'content', 'templates/content', 'search' );

get_footer();