<?php

define( 'PELICULA_ROOT', get_template_directory_uri() );
define( 'PELICULA_ROOT_DIR', get_template_directory() );
define( 'PELICULA_ASSETS_ROOT', PELICULA_ROOT . '/assets' );
define( 'PELICULA_ASSETS_ROOT_DIR', PELICULA_ROOT_DIR . '/assets' );
define( 'PELICULA_ASSETS_CSS_ROOT', PELICULA_ASSETS_ROOT . '/css' );
define( 'PELICULA_ASSETS_CSS_ROOT_DIR', PELICULA_ASSETS_ROOT_DIR . '/css' );
define( 'PELICULA_ASSETS_JS_ROOT', PELICULA_ASSETS_ROOT . '/js' );
define( 'PELICULA_ASSETS_JS_ROOT_DIR', PELICULA_ASSETS_ROOT_DIR . '/js' );
define( 'PELICULA_INC_ROOT', PELICULA_ROOT . '/inc' );
define( 'PELICULA_INC_ROOT_DIR', PELICULA_ROOT_DIR . '/inc' );
