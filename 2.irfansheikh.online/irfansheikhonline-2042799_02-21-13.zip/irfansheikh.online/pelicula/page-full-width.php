<?php
/*
Template Name: Qode Full Width Template
*/

get_header();

// Include content template
pelicula_template_part( 'content', 'templates/content' );

get_footer();