AOS.init({
  duration: 1200
});