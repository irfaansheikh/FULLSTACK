$(document).ready(function(){
	$('.sleekslider').sleekslider({
		thumbs: ['wallhaven-27263-thumbnail.jpg', 'wallhaven-16270-thumbnail.jpg', 'wallhaven-12018-thumbnail.jpg','wallhaven-3178-thumb.jpg','wallhaven-10742-thumb.jpg'],
		labels:['Slide 1', 'Slide 2', 'Slide 3', 'Slide 4', 'Slide 5'],
		speed:2000
	});
})