/**
 * Created by 23rd and Walnut
 * www.23andwalnut.com
 * User: Saleem El-Amin
 * Date: 6/8/11
 * Time: 9:39 AM
 */

var myPlaylist = [

    {
        mp3:'mix/1.mp3',
        oga:'mix/1.ogg',
        title:'Sample',
        artist:'Sample',
        rating:4,
        buy:'#',
        price:'0.99',
        duration:'0:30',
        cover:'mix/1.png'
    }
];
