// Component1.js
import React from "react";
import Component2 from "./Component2";

function Component1() {
  return (
    <>
      <h1>Hello!</h1>
      <Component2 />
    </>
  );
}

export default Component1;
