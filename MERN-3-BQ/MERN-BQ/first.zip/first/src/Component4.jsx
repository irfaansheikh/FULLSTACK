// Component4.js
import React from "react";
import Component5 from "./Component5";

function Component4() {
  return (
    <>
      <h1>Component 4</h1>
      <Component5 />
    </>
  );
}

export default Component4;
