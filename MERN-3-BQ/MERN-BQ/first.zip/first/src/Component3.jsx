// Component3.js
import React from "react";
import Component4 from "./Component4";

function Component3() {
  return (
    <>
      <h1>Component 3</h1>
      <Component4 />
    </>
  );
}

export default Component3;
