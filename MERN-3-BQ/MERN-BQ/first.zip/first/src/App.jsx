// App.js
import React from "react";
import UserProvider from "./userProvider";
import Component1 from "./Component1";

function App() {
  return (
    <UserProvider>
      <Component1 />
    </UserProvider>
  );
}

export default App;
