
function multiply(){
	var n1=document.getElementById("pkr").value;
	var n2=document.getElementById("usd").value;
	var mul=parseInt(n1)*parseInt(n2);
	document.getElementById("multiply").innerHTML=mul;
}
