# website-clone

> python2.7

> 不支持JS动态加载的站点爬取


__扒站小能手__

将指定页面的css、js、image（包括css内的）都爬取到本地并自动建立相应文件夹结构

__说明__

* -h or --help 说明
* -u or --url 站点网址(site url)
* -d or --dir [可选]保存本地目录，默认为站点域名(which directory to save files[op
tion])

__例子(example)__

* py clone.py -u http://paperen.com
* clone -u http://paperen.com -d test (windows下exe)

[http://paperen.com/post/website-clone](http://paperen.com/post/website-clone "扒站小能手")