# Calculator

Calculator created with HTML, CSS and JS.

[Live Demo](https://michalosman.github.io/calculator/) :point_left:
