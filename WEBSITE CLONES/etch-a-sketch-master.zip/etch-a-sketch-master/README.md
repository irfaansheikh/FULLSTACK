# Etch a Sketch

Etch a sketch game created with HTML, CSS and JS.

[Live Demo](https://michalosman.github.io/etch-a-sketch/) :point_left:
