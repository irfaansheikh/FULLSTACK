# Covid-19-Simulator
A Covid-19 simulation and the effect of social distancing
