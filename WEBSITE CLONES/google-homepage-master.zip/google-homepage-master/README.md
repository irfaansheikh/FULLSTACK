# Google Homepage

Google homepage clone created with HTML and CSS.

[Live Demo](https://michalosman.github.io/google-homepage/) :point_left:
