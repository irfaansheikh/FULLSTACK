* [Katarzyna Kaswen-Wilk's Solution](https://github.com/kikupiku/fakebook) - [View in Browser](https://odinbook-kikupiku.herokuapp.com/)
* [Julio's solution](https://github.com/julio22b/facebook-clone-api) - [View in Browser](https://facebook-clone-odin.herokuapp.com/users/log-in)
* [barrysweeney's Solution](https://github.com/barrysweeney/TOPBOOK) - [View in browser](https://calm-falls-42453.herokuapp.com/)
* [ranmaru22's Solution](https://github.com/ranmaru22/odinbook) - [View in Browser](https://secret-lowlands-14471.herokuapp.com/)
