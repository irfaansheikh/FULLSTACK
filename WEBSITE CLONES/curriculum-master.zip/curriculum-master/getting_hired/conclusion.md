### Final Words

I hope you're reading this from your new office.  If you got a job after doing the Odin Project, [let us know!](https://discord.com/invite/V75WSQG)  We'd love to hear how everything went, and we have a Discord channel where anyone can share their success stories.  The whole reason for putting this project out there is to try and onboard more people into the web development profession and tech in general.  Hopefully your success will inspire even more people to give it a shot.

So build some kick ass software, learn as much as you can, and pay it forward when you're able.  **Thanks for participating in the project!!!**
