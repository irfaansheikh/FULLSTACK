Our terms of use are located here: https://github.com/TheOdinProject/theodinproject/blob/master/legal_terms_of_use.md
