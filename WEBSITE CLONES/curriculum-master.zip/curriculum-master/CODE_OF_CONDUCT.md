The Odin Project's Code of Conduct is found in their main repository's `doc` folder. [LINK](https://github.com/TheOdinProject/theodinproject/blob/master/doc/code_of_conduct.md)
