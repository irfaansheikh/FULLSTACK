# Git Conclusion

## What You've Learned
A brief summary about what the student has learned in this course and why it will serve them well.


## Where to Learn More about Git
Where they can learn more about this topic and get better. Include some resources, books, other courses etc. Also advice them on how to practice the skills taught in this course
