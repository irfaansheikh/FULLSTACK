# Working with Git Branches
A brief summary about what this lesson is about and why the topics or concepts it covers are important.

## Learning outcomes
*Look through these now and then use them to test yourself after doing the assignment*

what the student is expected to know or be able to do by the end of this lesson

* Learning outcome 1
* Learning outcome 2
* Learning outcome 3

## Assignment
The list of resources the user will go through to learn about the topic of this lesson. Have no more than 5 resources, ideally no more than three.

## Exercises
A group of exercises (If Applicable) for the student to complete in relation to the topic taught in the lesson.

## Additional Resources
*This section contains helpful links to other content. It isn't required, so consider it supplemental for if you need to dive deeper into something*

Link to no more than three additional resources to avoid this section becoming too cluttered.
