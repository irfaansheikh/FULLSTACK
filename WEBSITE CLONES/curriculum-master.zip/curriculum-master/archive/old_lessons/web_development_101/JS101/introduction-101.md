As of today the contents of this gitbook have been made LIVE on [theodinproject.com](https://www.theodinproject.com/courses/foundations)

Feel free to continue going through them here if that suits you, I'm not going to delete anything anytime soon.. and will probably continue to use this gitbook as a staging site for other new content.  However, by going through the site itself you can keep track of your progress better.



BIG STINKING THANK YOU to everyone who's taken this course and provided feedback along the way!



