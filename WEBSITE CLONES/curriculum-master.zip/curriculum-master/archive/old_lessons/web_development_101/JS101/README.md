# This is the beginning of the JS curriculum!!  

How I envision it playing out:  Stub out the lessons for each section (like I've done here) with simple descriptions of the content and then go through and start filling them out.

This is almost definitely going to change... things are likely to be moved quite a lot once we start actually writing stuff, but for now the tentative order of the lessons here is:

It is __very__ likely that several of those lessons will be broken down into multiple smaller lessons.  I advise that we keep them together in one file for now and break them up as needed once things start getting too long.

## PLEASE
If you have feedback about the order or content of any of the lessons let someone know. Feel free to simply add your feedback to the lessons themselves or drop it in Gitter somewhere (you might ping @codyloyd, I'm kind of heading the project at this point).


## NOTES:
1. May be a good idea to move Arrays to second-steps... it's really hard to do too many useful things with arrays without using loops or functions, neither of which we've learned yet in first-steps.  I'm leaving it for now, but may consider moving it later.
