# License

This curriculum is licensed under the [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License](http://creativecommons.org/licenses/by-nc-sa/4.0/).  

It basically means you can do whatever you want with the material as long as it's for non-commercial use but you've got to attribute the original author ([Erik Trautman](http://github.com/eriktrautman)) and share any derivative works under the same license.

If you're interested in using the curriculum for commercial purposes or otherwise licensing material, feel free to get in touch at [contact@theodinproject.com](mailto:contact@theodinproject.com).