import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  container: {

  },
  name: {
    textAlign: 'center',
  }
});

export default styles;
