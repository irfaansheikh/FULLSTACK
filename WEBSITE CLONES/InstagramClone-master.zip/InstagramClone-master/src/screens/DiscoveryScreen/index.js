import React from 'react';
import { View, Text } from 'react-native';

const DiscoveryScreen = () => (
  <View style={{backgroundColor: "blue", height: 1500}}>
    <Text style={{textAlign: 'center', marginTop: 300, fontSize: 30, color: 'white'}}>Discovery</Text>
  </View>
)

export default DiscoveryScreen;
