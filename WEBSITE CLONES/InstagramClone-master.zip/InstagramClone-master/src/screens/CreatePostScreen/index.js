import React from 'react';
import { View, Text } from 'react-native';

const CreatePostScreen = () => (
  <View style={{backgroundColor: "green", height: 1500}}>
    <Text style={{textAlign: 'center', marginTop: 300, fontSize: 30, color: 'white'}}>Create Post</Text>
  </View>
)

export default CreatePostScreen;
