import { StyleSheet} from "react-native";

const styles = StyleSheet.create({
  container: {

  },
});

export default styles;
