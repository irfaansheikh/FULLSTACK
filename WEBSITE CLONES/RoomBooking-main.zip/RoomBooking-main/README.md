# Room Booking

A Python app which allows receptionists to preview and manage quest's reservations.

## Getting started

1. Download ZIP file or clone repository.
2. Extract files.
3. Run app by double clicking RoomBooking.py file.

## Built with

- [Python](https://docs.python.org/3/)
- [QtDesigner](https://doc.qt.io/qtforpython/)
