# Compound Interest Calculator

Class: DES350 - Digital Media Design IV

By: Gene Parcellano

A simple compound interest calculator.
