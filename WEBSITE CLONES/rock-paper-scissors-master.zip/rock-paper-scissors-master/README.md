# Rock Paper Scissors

Rock paper scissors game created with HTML, CSS and JS.

[Live Demo](https://michalosman.github.io/rock-paper-scissors/) :point_left:
