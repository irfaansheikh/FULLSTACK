import CVPreview from "./CVPreview";

export default CVPreview;
