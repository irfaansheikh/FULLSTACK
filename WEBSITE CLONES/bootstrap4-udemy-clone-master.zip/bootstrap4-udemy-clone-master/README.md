# bootstrap4-udemy-clone
A clone of Udemy website using bootstrap 4 final. This is the project files from a tutorial.

[Watch full video tutorial](https://www.youtube.com/watch?v=ut9H4QHbOB4&list=PLnBvgoOXZNCN20--39IKuF_DbINp4JfLq)

## Usage
1. Clone or download
2. Click on index.html and view on your browser
Enjoy

That's all, you are good to go.


I can join your team, you can contact me.

## How to thank me
* Star this repo
Follow me on my social media handles
* Subscribe on [Youtube](http://youtube.com/c/braintemorg)
* Follow on [Twitter](http://twitter.com/braintem)
* Follow on [Instagram](http://instagram.com/daveozoalor)
* Like on [Facebook](http://fb.com/braintem)


## Contacts

* You can reach the me on `daveozoalor@gmail.com`, I'd like to join your team.
* Just buzz me up on [facebook](http://facebook.com/daveozoalor)

## License

This software is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT).
