import initializeWebsite from "./website";

initializeWebsite();
