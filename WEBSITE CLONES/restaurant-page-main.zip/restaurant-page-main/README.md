# Restaurant page

Restaurant page created with HTML, CSS and JS.

[Live Demo](https://michalosman.github.io/restaurant-page/) :point_left:
