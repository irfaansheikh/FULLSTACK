# Weather App

Weather app created with HTML, CSS and JS.

[Live Demo](https://michalosman.github.io/weather-app/) :point_left:
