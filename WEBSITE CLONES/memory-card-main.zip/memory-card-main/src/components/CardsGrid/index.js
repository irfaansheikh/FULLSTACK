import CardsGrid from 'CardsGrid'

export default CardsGrid