import Scoreboard from './Scoreboard'

export default Scoreboard
