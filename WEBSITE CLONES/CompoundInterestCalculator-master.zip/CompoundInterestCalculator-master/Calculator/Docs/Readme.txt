﻿https://docs.docker.com/engine/examples/dotnetcore/#build-and-run-the-docker-image
