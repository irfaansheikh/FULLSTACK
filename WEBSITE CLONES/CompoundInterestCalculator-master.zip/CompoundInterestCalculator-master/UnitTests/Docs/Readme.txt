﻿Required packages for selenium:

Selenium.PhantomJS.WebDriver		[optional]
Selenium.Support
Selenium.WebDriver
Selenium.WebDriver.ChromeDriver
System.Security.Permissions
