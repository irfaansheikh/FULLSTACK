# Website Cloner

its a desktop app that allow users to download website files on computer ,
it help to download a full frontend source code 
html,css,js,images ...
 
 # Show some ⭐ to the repo for support

## Screenshots

![Downloading](https://i.imgur.com/yvwn7mt.png)


- [Youtube Channel](https://www.youtube.com/c/XSLAYERTN)
- [Linkedin](https://i.imgur.com/yvwn7mt.png)
